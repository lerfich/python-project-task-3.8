# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['coolp']

package_data = \
{'': ['*']}

install_requires = \
['argparse>=1.4.0,<2.0.0',
 'isort>=5.11.4,<6.0.0',
 'matplotlib>=3.6.2,<4.0.0',
 'pandas==1.5.1',
 'poethepoet>=0.16.5,<0.17.0',
 'pytest>=7.2.0,<8.0.0']

entry_points = \
{'console_scripts': ['start = coolp.__init__:start',
                     'test = coolp.__init__:test']}

setup_kwargs = {
    'name': 'coolp',
    'version': '0.1.0',
    'description': '',
    'long_description': 'Инструкция по запуску проекта:\n(Команды вводим из корня папки проекта)\n\n1. python3 -m pip install . (для установки зависимостей)\n2. poetry shell (для вхождения в окружение)\n3. start GlobalLandTemperaturesByMajorCity 1999 (для отработки основного алгоритма (таблицу лучше эту же, а год можно любой от 1950))\n4. test (для юнит-теста)\n',
    'author': 'lerfich',
    'author_email': 'nikita.serg.12@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
